CREATE OR REPLACE TRANSIENT TABLE sales_db.raw_schema.orders_status
 (
	ORDER_ID   INTEGER,
	STATUS     VARCHAR (100),
    CITY    VARCHAR (100),
	CREATED_AT DATE,
	UPDATED_AT DATE
);
INSERT INTO sales_db.raw_schema.orders_status (ORDER_ID, STATUS,CITY, CREATED_AT, UPDATED_AT) 
VALUES (1, 'PROCESSED','MUMBAI'    ,'2025-01-01','2025-01-04'),
       (2, 'SHIPPED'  ,'DELHI'     ,'2025-01-02','2025-01-04'),
       (3, 'SHIPPED'  ,'BANGALORE' ,'2025-01-03','2025-01-04'), 
	   (4, 'PROCESSED','CHENNAI'   ,'2025-01-04','2025-01-04'),
	   (5, 'PROCESSED','PUNE'      ,'2025-01-04','2025-01-04');
--
select from orders_status order by order_id
--/////////////////////////////////////Timestamp strategy example///////////////////////////////////////////////
--snapshots/scd_ts_order_status.sql
{% snapshot scd_ts_order_status %}
    {{
        config(
             
            target_schema='mart',
            unique_key='order_id',
            strategy='timestamp',
            updated_at='updated_at'
        )
    }}
    select * from {{ ref('stg_orders_status') }}
{% endsnapshot %}

------------------------------------------------------------------------
-- Run snapshot

dbt snapshot --select  <file name inside snapshot folder>
dbt snapshot --select  scd_ts_order_status

------------------------------------------------------------------------

--update the status and  updated_at for two cities 
UPDATE  sales_db.raw_schema.orders_status
SET STATUS = 'DELIVERED'
, UPDATED_AT = '2025-01-04'
where CITY in('PUNE' )


dbt run --select stg_orders_status
dbt snapshot --select  scd_ts_order_status


select * from sales_db.raw_schema.orders_status where CITY ='PUNE' 


select * from sales_db.stg.stg_orders_status where CITY ='PUNE' 


select * from sales_db.mart.scd_ts_order_status where city ='pune' 


--/////////////////////////////////////Check strategy example://///////////////////////////////////////

--Check strategy example:
--scd_chk_order_status.sql

{% snapshot scd_chk_order_status %}
    {{
        config(
           
		    target_schema='mart',
			unique_key='ORDER_ID',
            strategy='check',
            check_cols=['STATUS', 'CITY'],
        )
    }}
    select * from {{ ref('stg_orders_status') }}
{% endsnapshot %}

------------------------------------------------------------------------
-- Run snapshot

dbt run --select stg_orders_status
dbt snapshot --select  scd_chk_order_status

select * from sales_db.mart.scd_chk_order_status

------------------------------------------------------------------------

--update the status and  city for order 3 and 5
UPDATE  sales_db.raw_schema.orders_status
SET STATUS = 'DELIVERED1'
 where ORDER_ID =3
  
            
 UPDATE  sales_db.raw_schema.orders_status
SET CITY = 'PUNE1'
 where ORDER_ID =5          
            

dbt run --select stg_orders_status
dbt snapshot --select  scd_chk_order_status



 ------------------------------------------------------------------------
select * from   scd_chk_order_status where ORDER_ID in (3,5)




--//////////////////////////////////////////////////////////////////////////////////////////////////////////////


--Check strategy example:
--scd_hard_del_orders_status.sql

{% snapshot scd_hard_del_orders_status %}
    {{
        config(
            target_schema='mart',
			unique_key='ORDER_ID',
            strategy='check',
            check_cols=['STATUS', 'CITY'],
			invalidate_hard_deletes=True
        )
    }}
    select * from {{ ref('stg_orders_status') }}
{% endsnapshot %}

dbt run --select stg_orders_status
dbt snapshot --select  scd_hard_del_orders_status
 

select * from sales_db.raw_schema.orders_status 
select * from sales_db.stg.stg_orders_status  
select * from sales_db.mart.scd_hard_del_orders_status




delete from sales_db.raw_schema.orders_status where ORDER_ID =1  

dbt run --select stg_orders_status
dbt snapshot --select  scd_hard_del_orders_status

select * from sales_db.raw_schema.orders_status 
select * from sales_db.stg.stg_orders_status  
select * from sales_db.mart.scd_hard_del_orders_status







Hooks in dbt
=================

Introduction to Hooks in dbt
Hooks:

Hooks in dbt are pieces of SQL that run at specified times in the dbt workflow. They can be used to perform custom actions like logging, auditing, or manipulating data.

Basic Hooks
-----------
1.Pre-Hooks and Post-Hooks	:Introduction to pre-hooks and post-hooks.
2.Basic Pre-Hook Example		:Logging before model runs.
3.Basic Post-Hook Example		:Logging after model runs.

Intermediate Hooks
------------------
1.Conditional Hooks:Running hooks based on conditions.
2.Using Hooks for Data Quality Checks: Implementing hooks for ensuring data quality.

Advanced Hooks
--------------
Complex SQL in Hooks: Writing complex SQL in hooks.
Chaining Hooks      : Running multiple hooks sequentially.

Step-by-Step Guide with Examples
====================================
Basic Hooks
-----------
1. Pre-Hooks and Post-Hooks
---------------------------
Pre-Hook: Executes before a model runs.
Post-Hook: Executes after a model runs.
---------------------------
2. Basic Pre-Hook Example
---------------------------
**File:** `models/staging/customers.sql`

{{ config(
          pre_hook="INSERT INTO run_logs (model, action, timestamp) 
	          VALUES ('customers', 'start', current_timestamp())"
          ) 
}}

SELECT * FROM {{ ref('raw_customers') }}
---------------------------
3. Basic Post-Hook Example
---------------------------
**File:** `models/staging/customers.sql`

{{ config(
    post_hook="INSERT INTO run_logs (model, action, timestamp) VALUES ('customers', 'end', current_timestamp())"
) }}

SELECT * FROM {{ ref('raw_customers') }}
-----------------------------------------------------------------------------Step-by-Step Guide with Examples
================================
E.g:-
--Step1:- Create a table in snowflake to hold logs
create table if not exists dbt_audits
   (
    id int autoincrement start 1 increment 1,
    audit_type varchar(50),
    created_at timestamp default current_timestamp()
    );
select * from dbt_audits;
insert into dbt_audits(audit_type) values('run_end');
select * from dbt_audits;

--Step2:- Create Pre-Hook and Post-Hook to store data into audit table
In dbt_project.yml
on-run-start: "insert into shop.dbt_audits(audit_type) values('run_start')"
on-run-end  : "insert into shop.dbt_audits(audit_type) values('run_end')"

--Save dbt_project.yml
--Step3:- Run Any Model
dbt run --select tickets

---------------------------
on-run-start: "insert into demo_db.public.dbt_audits (audit_type) values ('run_start'); commit;"
on-run-end: "insert into demo_db.public.dbt_audits (audit_type) values ('run_end'); commit;"

models:
  pre-hook: "insert into demo_db.public.dbt_audits (audit_type) values ('model_start'); commit;"
  post-hook: "insert into demo_db.public.dbt_audits (audit_type) values ('model_end'); commit;"

demo_db:
  staging:
    +materialized: table


------------------------------------------------------
{% macro insert_audits(action_name) %}
insert into demo_db.public.dbt_audits (audit_type)
values ('{{ action_name }}');
commit;
{% endmacro %}


source-paths: ["models"]
analysis-paths: ["analysis"]
test-paths: ["tests"]
data-paths: ["data"]
macro-paths: ["macros"]
snapshot-paths: ["snapshots"]

target-path: "target"
clean-targets:
  - "target"
  - "dbt_modules"

on-run-start: "{{ insert_audits('run_start') }}"
on-run-end: "{{ insert_audits('run_end') }}"

models:
  pre-hook: "{{ insert_audits('model_start') }}"
  post-hook: "{{ insert_audits('model_end') }}"
  demo_db:
    staging:
      +materialized: table

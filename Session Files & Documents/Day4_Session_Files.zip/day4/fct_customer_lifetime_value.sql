--models/staging/stg_customers.sql
{{ config(materialized='view') }}
SELECT
    id AS customer_id,
     upper(email) AS email,
    created_at
FROM {{ source('raw', 'customers') }}
------------------------------------------------------------------------------------
--models/staging/stg_orders.sql
{{ config(materialized='view') }}
SELECT
    id AS order_id,
    customer_id,
    order_status,
    order_amount,
    created_at
FROM {{ source('raw', 'orders') }}
------------------------------------------------------------------------------------
--models/intermediate/int_completed_orders.sql
{{ config(materialized='ephemeral') }}
select
    id as order_id,
    to_date(created_at) as order_date,
    user_id as customer_id,
    product_id,
    quantity,
    unit_price,
    quantity * unit_price as order_amount
from {{ ref('stg_orders') }}
WHERE status = 'COMPLETED'
------------------------------------------------------------------------------------
--models/marts/fct_customer_lifetime_value.sql
{{ config(
          materialized='table',
          tags=['customer', 'lifetime_value', 'finance']
     ) 
}}

SELECT
    c.customer_id,
    SUM(e.order_amount) AS lifetime_value,
    COUNT(e.order_id) AS total_orders
FROM {{ ref('stg_customers') }} c
JOIN {{ ref('int_completed_orders') }} e 
    ON c.customer_id = e.customer_id
GROUP BY c.customer_id
------------------------------------------------------------------------------------
 
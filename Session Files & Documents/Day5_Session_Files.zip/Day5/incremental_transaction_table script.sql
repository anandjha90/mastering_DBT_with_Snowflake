--Sample Transaction Table Setup
-- Create a source transaction table
CREATE TABLE transactions (
    trans_id VARCHAR(20),
    customer_id INT,
    product_id INT,
    amount DECIMAL(10,2),
    transaction_date TIMESTAMP,
    status VARCHAR(20),
    last_updated TIMESTAMP
);

-- Insert initial data
INSERT INTO transactions VALUES
('T1001', 101, 1, 999.99, '2023-01-01 10:00:00', 'completed', '2023-01-01 10:05:00'),
('T1002', 102, 2, 699.99, '2023-01-01 11:00:00', 'completed', '2023-01-01 11:05:00'),
('T1003', 103, 3, 199.99, '2023-01-01 12:00:00', 'pending', '2023-01-01 12:05:00');

-------------------------------------------------------------------------------------------------------
--1. Append Strategy (New Transactions Only)
--Create models/incremental_transactions_append.sql:
{{
  config(
    materialized='incremental',
    unique_key='trans_id',
    incremental_strategy='append'
  )
}}
SELECT
    trans_id,
    customer_id,
    product_id,
    amount,
    transaction_date,
    status,
    last_updated
FROM {{ source('raw_src', 'transactions') }}
{% if is_incremental() %}
  -- Only get transactions newer than our latest record
  WHERE last_updated > (SELECT MAX(last_updated) FROM {{ this }})
{% endif %}
====================================================================
--Run model 
dbt run --select incremental_transactions_append

select * from SALES_DB.DBT_VB.INCREMENTAL_TRANSACTIONS_APPEND

====================================================================
--Add new transactions:

INSERT INTO transactions VALUES
('T1004', 104, 4, 249.99, '2023-01-02 09:00:00', 'completed', '2023-01-02 09:05:00'),
('T1005', 105, 5, 149.99, '2023-01-02 10:00:00', 'pending', '2023-01-02 10:05:00');

select * from SALES_DB.raw_schema.transactions

====================================================================
--Run model 
dbt run --select incremental_transactions_append

====================================================================

--Verify only new transactions were added (T1004, T1005)

select * from SALES_DB.DBT_VB.INCREMENTAL_TRANSACTIONS_APPEND

-------------------------------------------------------------------------------------------------------
--2. Merge Strategy (Update Existing Transactions)
--Create models/incremental_transactions_merge.sql:
{{
  config(
    materialized='incremental',
    unique_key='trans_id',
    incremental_strategy='merge'
  )
}}

SELECT
    trans_id,
    customer_id,
    product_id,
    amount,
    transaction_date,
    status,
    last_updated
FROM {{ source('raw_src', 'transactions') }}
{% if is_incremental() %}
  -- Get all transactions updated since our last run
  WHERE last_updated > (SELECT MAX(last_updated) FROM {{ this }})
   
{% endif %}
====================================================================
--Run model 
dbt run --select incremental_transactions_merge

select * from  sales_db.dbt_vb.incremental_transactions_merge
====================================================================

--Update a transaction status and add new ones:
UPDATE transactions 
SET status = 'completed'
, last_updated = '2025-06-29 14:00:00'
WHERE trans_id = 'T1003';

INSERT INTO transactions VALUES
('T1006', 106, 6, 59.99, '2025-06-29 15:00:00', 'completed', '2025-06-29 15:05:00');
====================================================================
--Run model 
dbt run --select incremental_transactions_merge
====================================================================
--Verify T1003 status changed and T1006 was added

select * from  sales_db.dbt_vb.incremental_transactions_merge


-------------------------------------------------------------------------------------------------------
--3. Delete+Insert Strategy (Full Refresh of Recent Data)
--Create models/incremental_transactions_delete_insert.sql:
{{
  config(
    materialized='incremental',
    unique_key='trans_id',
    incremental_strategy='delete+insert'
  )
}}

SELECT
    trans_id,
    customer_id,
    product_id,
    amount,
    transaction_date,
    status,
    last_updated
FROM {{ source('raw_src', 'transactions') }}
{% if is_incremental() %}
  -- Refresh transactions from the last 1 day
  WHERE transaction_date >= DATEADD(day, -1, CURRENT_DATE)
{% endif %}

====================================================================
--Run model 
dbt run --select incremental_transactions_delete_insert

select * from  sales_db.dbt_vb.incremental_transactions_delete_insert

====================================================================
--Modify transactions and add new ones:
UPDATE transactions 
SET amount = 179.99
, last_updated = '2025-06-29 15:00:00'
WHERE trans_id = 'T1003';

INSERT INTO transactions VALUES
('T1007', 107, 7, 39.99, '2025-06-29 15:00:00', 'completed', '2025-06-29 15:01:00');
====================================================================
--Run model 
dbt run --select incremental_transactions_delete_insert
====================================================================

--Verify T1003 amount changed and T1007 was added (older transactions remain unchanged)
select * from sales_db.dbt_vb.incremental_transactions_delete_insert

-------------------------------------------------------------------------------------------------------
--4. Insert Overwrite (Partitioned by Date)
--Create models/incremental_transactions_overwrite.sql:
{{
  config(
    materialized='incremental',
    incremental_strategy='insert_overwrite',
	partition_by={
                  "field": "transaction_date",
              "data_type": "timestamp"
                } 
  )
}}

SELECT
    trans_id,
    customer_id,
    product_id,
    amount,
    transaction_date,
    status,
    last_updated
FROM {{ source('raw_src', 'transactions') }}

{% if is_incremental() %}
  -- Overwrite partitions from the last 1 days
  WHERE DATE(transaction_date) >= DATEADD(day, -1, CURRENT_DATE)
{% endif %}

====================================================================
--Run model 
dbt run --select incremental_transactions_overwrite

select * from sales_db.dbt_vb.incremental_transactions_overwrite
====================================================================

--Add transactions for multiple dates:
INSERT INTO transactions VALUES
('T1008', 108, 8, 89.99, '2025-06-29 15:00:00', 'completed', '2025-06-29 15:01:00'),
('T1009', 109, 9, 129.99, '2025-06-29 15:00:00', 'pending', '2025-06-29 15:01:00');
====================================================================
--Run model 
dbt run --select incremental_transactions_overwrite
====================================================================

--Verify only Jan 2-4 partitions were overwritten (Jan 1 data remains intact)

Real-World Variations to Practice
Late-arriving facts:

INSERT INTO transactions VALUES
('T1010', 110, 10, 79.99, '2023-01-01 13:00:00', 'completed', '2023-01-05 11:00:00');

--Test how each strategy handles data with old transaction dates but new last_updated

--Status changes:
UPDATE transactions 
SET status = 'refunded', amount = -699.99, last_updated = '2023-01-05 12:00:00'
WHERE trans_id = 'T1002';
--Verify merge strategy captures the refund

--High-volume testing:


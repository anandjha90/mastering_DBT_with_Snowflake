--🔁 For all bronze files:
sources:
  - name: raw
    database: SHOPVERSE_DB
    schema: RAW
    tables:
      - name: orders
      - name: customers
      - name: products
      - name: payments
--🔶 models/bronze/ — Raw Ingestion Layer
--Each file here pulls directly from raw source tables.

--✅ bronze_orders.sql
{{ config(materialized='view') }}
select * from {{ source('raw', 'orders') }}
--✅ bronze_customers.sql
{{ config(materialized='view') }}
select * from {{ source('raw', 'customers') }}
--✅ bronze_products.sql
{{ config(materialized='view') }}
select * from {{ source('raw', 'products') }}
--✅ bronze_payments.sql
{{ config(materialized='view') }}
select * from {{ source('raw', 'payments') }}

--🟦 models/staging/ — Cleansed & Typed Layer
--✅ stg_orders.sql
{{ config(materialized='view') }}
select
  order_id,
  customer_id,
  product_id,
  order_date::date as order_date,
  status
from {{ ref('bronze_orders') }}
--🎯 Renames and casts fields.
--✅ stg_customers.sql
{{ config(materialized='view') }}
select
  customer_id,
  first_name,
  last_name,
  email,
  phone,
  country_code
from {{ ref('bronze_customers') }}
--✅ stg_products.sql
{{ config(materialized='view') }}
select
  product_id,
  product_name,
  category,
  price::float as price,
  cost::float as cost
from {{ ref('bronze_products') }}
--✅ stg_payments.sql
{{ config(materialized='view') }}
select
  payment_id,
  order_id,
  payment_method,
  payment_status,
  amount::float as amount
from {{ ref('bronze_payments') }}
--✅ stg_country.sql (from seed)
{{ config(materialized='view') }}
select
  country_code,
  country_name,
  region
from {{ ref('country') }}
--This reads from seeds/country.csv. To load it:
dbt seed
--------------------------------
--🔁 models/silver/ — Reusable Business Logic
--✅ int_profit_calculation.sql
{{ config(materialized='table') }}

select
  o.order_id,
  o.product_id,
  o.customer_id,
  p.price,
  p.cost,
  {{ calculate_profit('p.price', 'p.cost') }} as profit
from {{ ref('stg_orders') }} o
join {{ ref('stg_products') }} p using (product_id)
--🎯 Uses macro calculate_profit(price, cost) from macros/calculate_profit.sql.
--✅ int_order_payments.sql
{{ config(materialized='table') }}
select
  o.order_id,
  o.customer_id,
  o.order_date,
  p.amount,
  p.payment_status
from {{ ref('stg_orders') }} o
left join {{ ref('stg_payments') }} p using (order_id)
--📌 Ensures all orders are joined with their payments, even if unpaid.
-------------------------------------------------------
--🟨 models/marts/ — Final Reporting Models
--✅ customer_profit.sql
{{ config(materialized='table') }}
select
  customer_id,
  sum(profit) as total_profit
from {{ ref('int_profit_calculation') }}
group by customer_id
--✅ product_profit.sql
{{ config(materialized='table') }}
select
  product_id,
  sum(profit) as total_profit,
  count(*) as total_orders
from {{ ref('int_profit_calculation') }}
group by product_id
--✅ country_profit_summary.sql
{{ config(materialized='table') }}
select
  c.country_name,
  c.region,
  sum(p.profit) as total_profit
from {{ ref('int_profit_calculation') }} p
join {{ ref('stg_customers') }} cu on p.customer_id = cu.customer_id
join {{ ref('stg_country') }} c on cu.country_code = c.country_code
group by c.country_name, c.region
--✅ payment_success_rate.sql
{{ config(materialized='table') }}
select
  payment_status,
  count(*) as total_count,
  round(100.0 * count(*) / sum(count(*)) over (), 2) as percentage
from {{ ref('stg_payments') }}
group by payment_status
--✅ unpaid_orders_audit.sql
{{ config(materialized='table') }}
select
  o.order_id,
  o.customer_id,
  o.order_date
from {{ ref('stg_orders') }} o
left join {{ ref('stg_payments') }} p using (order_id)
where p.order_id is null or p.payment_status != 'Success'
--Helps audit missing/unpaid orders.
--🔄 snapshots/snapshot_customers.sql

{% snapshot snapshot_customers %}
{{
  config(
    target_schema='snapshots',
    unique_key='customer_id',
    strategy='check',
    check_cols=['email', 'phone']
  )
}}

select * from {{ source('raw', 'customers') }}

{% endsnapshot %}
--Run it:
--dbt snapshot
-------------------------------------------------------------------
-- Below are schema.yml files (docs + tests) for each layer
--1.schema.yml for bronze/
-- models/bronze/schema.yml
version: 2

sources:
  - name: raw
    database: SHOPVERSE_DB
    schema: RAW
    tables:
      - name: orders
      - name: customers
      - name: products
      - name: payments

models:
  - name: bronze_orders
    description: Raw orders data from source system.
  - name: bronze_customers
    description: Raw customers data from source system.
  - name: bronze_products
    description: Raw products data from source system.
  - name: bronze_payments
    description: Raw payments data from source system.
--------------------------------------------------------------------------------
--2.schema.yml for staging
--models/staging/schema.yml
version: 2

models:
  - name: stg_orders
    description: Cleaned and typed orders table
    columns:
      - name: order_id
        tests: [not_null, unique]
      - name: customer_id
        tests: [not_null]
      - name: order_date
        tests: [not_null]

  - name: stg_customers
    description: Cleaned customers table
    columns:
      - name: customer_id
        tests: [not_null, unique]
      - name: email
        tests: [not_null, unique]

  - name: stg_products
    description: Cleaned products table
    columns:
      - name: product_id
        tests: [not_null, unique]

  - name: stg_payments
    description: Cleaned payments table
    columns:
      - name: payment_id
        tests: [not_null, unique]
      - name: payment_status
        tests:
          - accepted_values:
              values: ['Success', 'Failed', 'Pending']

  - name: stg_country
    description: Country seed mapping
    columns:
      - name: country_code
        tests: [not_null, unique]
--------------------------------------------------------------------------------
--3. schema.yml for silver/
--models/silver/schema.yml
version: 2

models:
  - name: int_profit_calculation
    description: Calculates profit by order and product
    columns:
      - name: profit
        tests: [not_null]

  - name: int_order_payments
    description: Joins orders with payments
    columns:
      - name: order_id
        tests: [not_null]
--------------------------------------------------------------------------------
--4. schema.yml for marts/
--models/marts/schema.yml
version: 2

models:
  - name: customer_profit
    description: Profit summary at customer level
    columns:
      - name: customer_id
        tests: [not_null]

  - name: product_profit
    description: Profit summary at product level
    columns:
      - name: product_id
        tests: [not_null]

  - name: country_profit_summary
    description: Profit summary by country and region

  - name: payment_success_rate
    description: Breakdown of payment status percentage

  - name: unpaid_orders_audit
    description: Orders that are unpaid or failed
    columns:
      - name: order_id
        tests: [not_null]
--------------------------------------------------------------------------------










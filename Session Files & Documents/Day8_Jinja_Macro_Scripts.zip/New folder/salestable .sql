CREATE TABLE sales_data (
    month DATE,
    current_sales INTEGER,
    previous_sales INTEGER
);
--
INSERT INTO sales_data (month, current_sales, previous_sales) VALUES
('2024-01-01', 1000, 800),
('2024-02-01', 1200, 1000),
('2024-03-01', 1500, 1200),
('2024-04-01',  900, 0),
('2024-05-01', 1100, 1100);
--
--macros/calculate_growth.sql
{% macro calculate_growth(current_period_column, previous_period_column) %}
  CASE
    WHEN {{ previous_period_column }} != 0 THEN
      ({{ current_period_column }} - {{ previous_period_column }}) / {{ previous_period_column }} * 100
    ELSE
      NULL
  END
{% endmacro %}
--
--models/calculate_growth_model.sql

{{ config(materialized='table') }}

WITH source_data AS (
  SELECT * FROM {{ ref('sales_data') }}
)

SELECT
  month,
  current_sales,
  previous_sales,
  {{ calculate_growth('current_sales', 'previous_sales') }} AS sales_growth_percentage
FROM source_data


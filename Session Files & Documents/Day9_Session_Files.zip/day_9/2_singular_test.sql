tests/check_price_non_negative.sql
{{config(severity = 'warn')}}

SELECT
*
FROM
{{ source('raw_src','raw_orders') }}
WHERE unit_price < 0 and quantity < 0


--run only test 
dbt test --select  check_price_non_negative


---------fail case for not null------------------------------------------

select * from stg_products  where id in(199,200)


update stg_products
 set price =-100
 where id in(199,200)

 
update stg_products
 set price =100
 where id in(199,200)
tests/generic/checkt_non_negative.sql

{% test check_non_negative(model, column_name) %}

SELECT
*
FROM {{ model }}
WHERE {{ column_name }} <0

{% endtest %}

--run the test 
dbt test --select  stg_payment

---------fail case custom generic test ------------------------------------------

select * from stg_payment  where order_id  =1

Update stg_payment
set amount_inr =-amount_inr
 where order_id  =1


Update stg_payment
set amount_inr =abs(amount_inr)
 where order_id  =1

select * from stg_products
---------fail case for not null------------------------------------------
update stg_products
 set price =null
 where id in(199,200)

select * from stg_products where id in(199,200)
update stg_products
 set price =100
 where id in(199,200)
 
---------fail case for accepted_values-------------------------------------
update stg_products
 set category ='smartwatch111'
 where id =200


update stg_products
set category ='smartwatch'
 where id =200
 
---------fail case  for relationship------------------------------------------
 insert into stg_products values( 1003,'2025-07-19 23:26:53.703'	,'apple ','smartwatch','tablet',	73.19)
 
 delete from stg_products where id =1003
